    // public void check(){
    //     for (int i = 0; i < contactList.length; i++) {
    //         System.out.println(i);
    //     }
    // }